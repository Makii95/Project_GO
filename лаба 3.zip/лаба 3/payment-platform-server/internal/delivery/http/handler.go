package httpdelivery

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strings"

	"payment-platform-server/internal/domain"
	"payment-platform-server/internal/usecase"
)

type TestUseCase interface {
	GetTestMessage(ctx context.Context) (string, error)
	SaveDBTestMessage(ctx context.Context, message string) (string, error)
	RegisterUser(ctx context.Context, username string, password string) (domain.User, error)
	LoginUser(ctx context.Context, username string, password string) (string, error)
}

type authRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

type registerResponse struct {
	ID       int64  `json:"id"`
	Username string `json:"username"`
}

type loginResponse struct {
	Token string `json:"token"`
}

type TestHandler struct {
	useCase TestUseCase
}

func NewTestHandler(useCase TestUseCase) *TestHandler {
	return &TestHandler{
		useCase: useCase,
	}
}

func (h *TestHandler) RegisterRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/test", h.HandleTest)
	mux.HandleFunc("/dbtest", h.HandleDBTest)
	mux.HandleFunc("/register", h.HandleRegister)
	mux.HandleFunc("/login", h.HandleLogin)
}

func (h *TestHandler) HandleTest(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	message, err := h.useCase.GetTestMessage(r.Context())
	if err != nil {
		http.Error(w, "internal server error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write([]byte(message))
}

func (h *TestHandler) HandleDBTest(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	body, err := io.ReadAll(io.LimitReader(r.Body, 1<<20))
	if err != nil {
		http.Error(w, "failed to read request body", http.StatusBadRequest)
		return
	}

	message := strings.TrimSpace(string(body))
	if message == "" {
		http.Error(w, "request body is empty", http.StatusBadRequest)
		return
	}

	savedMessage, err := h.useCase.SaveDBTestMessage(r.Context(), message)
	if err != nil {
		http.Error(w, "internal server error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.WriteHeader(http.StatusCreated)
	_, _ = w.Write([]byte(savedMessage))
}

func (h *TestHandler) HandleRegister(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var request authRequest
	if err := json.NewDecoder(r.Body).Decode(&request); err != nil {
		http.Error(w, "invalid json body", http.StatusBadRequest)
		return
	}

	user, err := h.useCase.RegisterUser(r.Context(), request.Username, request.Password)
	if err != nil {
		switch {
		case errors.Is(err, usecase.ErrInvalidCredentials):
			http.Error(w, "username and password are required", http.StatusBadRequest)
		case errors.Is(err, usecase.ErrUserAlreadyExists):
			http.Error(w, "user already exists", http.StatusConflict)
		default:
			http.Error(w, "internal server error", http.StatusInternalServerError)
		}
		return
	}

	writeJSON(w, http.StatusCreated, registerResponse{
		ID:       user.ID,
		Username: user.Username,
	})
}

func (h *TestHandler) HandleLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var request authRequest
	if err := json.NewDecoder(r.Body).Decode(&request); err != nil {
		http.Error(w, "invalid json body", http.StatusBadRequest)
		return
	}

	token, err := h.useCase.LoginUser(r.Context(), request.Username, request.Password)
	if err != nil {
		if errors.Is(err, usecase.ErrInvalidCredentials) {
			http.Error(w, "invalid username or password", http.StatusUnauthorized)
			return
		}

		http.Error(w, "internal server error", http.StatusInternalServerError)
		return
	}

	writeJSON(w, http.StatusOK, loginResponse{Token: token})
}

func writeJSON(w http.ResponseWriter, statusCode int, value any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(statusCode)
	_ = json.NewEncoder(w).Encode(value)
}
