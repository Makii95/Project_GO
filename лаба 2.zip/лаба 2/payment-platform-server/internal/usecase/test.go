package usecase

import "context"

type MessageRepository interface {
	GetHelloMessage(ctx context.Context) (string, error)
	SaveMessage(ctx context.Context, message string) (string, error)
}

type TestUseCase struct {
	messageRepository MessageRepository
}

func NewTestUseCase(messageRepository MessageRepository) *TestUseCase {
	return &TestUseCase{
		messageRepository: messageRepository,
	}
}

func (u *TestUseCase) GetTestMessage(ctx context.Context) (string, error) {
	return u.messageRepository.GetHelloMessage(ctx)
}

func (u *TestUseCase) SaveDBTestMessage(ctx context.Context, message string) (string, error) {
	return u.messageRepository.SaveMessage(ctx, message)
}
