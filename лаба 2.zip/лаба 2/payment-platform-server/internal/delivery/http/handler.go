package httpdelivery

import (
	"context"
	"io"
	"net/http"
	"strings"
)

type TestUseCase interface {
	GetTestMessage(ctx context.Context) (string, error)
	SaveDBTestMessage(ctx context.Context, message string) (string, error)
}
 
type TestHandler struct {
	useCase TestUseCase
}

func NewTestHandler(useCase TestUseCase) *TestHandler {
	return &TestHandler{
		useCase: useCase,
	}
}

func (h *TestHandler) RegisterRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/test", h.HandleTest)
	mux.HandleFunc("/dbtest", h.HandleDBTest)
}

func (h *TestHandler) HandleTest(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	message, err := h.useCase.GetTestMessage(r.Context())
	if err != nil {
		http.Error(w, "internal server error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write([]byte(message))
}

func (h *TestHandler) HandleDBTest(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	body, err := io.ReadAll(io.LimitReader(r.Body, 1<<20))
	if err != nil {
		http.Error(w, "failed to read request body", http.StatusBadRequest)
		return
	}

	message := strings.TrimSpace(string(body))
	if message == "" {
		http.Error(w, "request body is empty", http.StatusBadRequest)
		return
	}

	savedMessage, err := h.useCase.SaveDBTestMessage(r.Context(), message)
	if err != nil {
		http.Error(w, "internal server error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.WriteHeader(http.StatusCreated)
	_, _ = w.Write([]byte(savedMessage))
}
