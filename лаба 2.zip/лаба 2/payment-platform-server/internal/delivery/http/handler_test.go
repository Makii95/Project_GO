package httpdelivery

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

type fakeTestUseCase struct {
	message string
	saved   string
	err     error
}

func (f fakeTestUseCase) GetTestMessage(ctx context.Context) (string, error) {
	return f.message, f.err
}

func (f fakeTestUseCase) SaveDBTestMessage(ctx context.Context, message string) (string, error) {
	if f.saved != "" {
		return f.saved, f.err
	}

	return message, f.err
}

func TestHandleTestReturnsHello(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{message: "Hello!"})

	request := httptest.NewRequest(http.MethodGet, "/test", nil)
	response := httptest.NewRecorder()

	handler.HandleTest(response, request)

	if response.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, response.Code)
	}

	if response.Body.String() != "Hello!" {
		t.Fatalf("expected body %q, got %q", "Hello!", response.Body.String())
	}
}

func TestHandleTestRejectsUnsupportedMethod(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{message: "Hello!"})

	request := httptest.NewRequest(http.MethodPost, "/test", nil)
	response := httptest.NewRecorder()

	handler.HandleTest(response, request)

	if response.Code != http.StatusMethodNotAllowed {
		t.Fatalf("expected status %d, got %d", http.StatusMethodNotAllowed, response.Code)
	}
}

func TestHandleTestReturnsInternalServerError(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{err: errors.New("usecase error")})

	request := httptest.NewRequest(http.MethodGet, "/test", nil)
	response := httptest.NewRecorder()

	handler.HandleTest(response, request)

	if response.Code != http.StatusInternalServerError {
		t.Fatalf("expected status %d, got %d", http.StatusInternalServerError, response.Code)
	}
}

func TestHandleDBTestSavesMessage(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{saved: "saved message"})

	request := httptest.NewRequest(http.MethodPost, "/dbtest", strings.NewReader("saved message"))
	response := httptest.NewRecorder()

	handler.HandleDBTest(response, request)

	if response.Code != http.StatusCreated {
		t.Fatalf("expected status %d, got %d", http.StatusCreated, response.Code)
	}

	if response.Body.String() != "saved message" {
		t.Fatalf("expected body %q, got %q", "saved message", response.Body.String())
	}
}

func TestHandleDBTestRejectsUnsupportedMethod(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{})

	request := httptest.NewRequest(http.MethodGet, "/dbtest", nil)
	response := httptest.NewRecorder()

	handler.HandleDBTest(response, request)

	if response.Code != http.StatusMethodNotAllowed {
		t.Fatalf("expected status %d, got %d", http.StatusMethodNotAllowed, response.Code)
	}
}

func TestHandleDBTestRejectsEmptyBody(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{})

	request := httptest.NewRequest(http.MethodPost, "/dbtest", strings.NewReader("   "))
	response := httptest.NewRecorder()

	handler.HandleDBTest(response, request)

	if response.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, response.Code)
	}
}

func TestHandleDBTestReturnsInternalServerError(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{err: errors.New("save error")})

	request := httptest.NewRequest(http.MethodPost, "/dbtest", strings.NewReader("message"))
	response := httptest.NewRecorder()

	handler.HandleDBTest(response, request)

	if response.Code != http.StatusInternalServerError {
		t.Fatalf("expected status %d, got %d", http.StatusInternalServerError, response.Code)
	}
}
