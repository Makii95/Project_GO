package repository

import (
	"context"
	"database/sql"
)

type PostgresMessageRepository struct {
	db      *sql.DB
	message string
}

func NewPostgresMessageRepository(db *sql.DB, message string) *PostgresMessageRepository {
	return &PostgresMessageRepository{
		db:      db,
		message: message,
	}
}

func (r *PostgresMessageRepository) InitSchema(ctx context.Context) error {
	const query = `
		CREATE TABLE IF NOT EXISTS test_messages (
			id SERIAL PRIMARY KEY,
			message TEXT NOT NULL,
			created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
		)
	`

	_, err := r.db.ExecContext(ctx, query)
	return err
}

func (r *PostgresMessageRepository) GetHelloMessage(ctx context.Context) (string, error) {
	select {
	case <-ctx.Done():
		return "", ctx.Err()
	default:
		return r.message, nil
	}
}

func (r *PostgresMessageRepository) SaveMessage(ctx context.Context, message string) (string, error) {
	const query = `
		INSERT INTO test_messages (message)
		VALUES ($1)
		RETURNING message
	`

	var savedMessage string
	err := r.db.QueryRowContext(ctx, query, message).Scan(&savedMessage)
	if err != nil {
		return "", err
	}

	return savedMessage, nil
}
