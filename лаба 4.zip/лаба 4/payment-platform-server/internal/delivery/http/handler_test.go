package httpdelivery

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"payment-platform-server/internal/domain"
	"payment-platform-server/internal/usecase"
)

type fakeTestUseCase struct {
	message string
	saved   string
	user    domain.User
	token   string
	order   domain.Order
	orders  []domain.Order
	err     error
}

func (f fakeTestUseCase) GetTestMessage(ctx context.Context) (string, error) {
	return f.message, f.err
}

func (f fakeTestUseCase) SaveDBTestMessage(ctx context.Context, message string) (string, error) {
	if f.saved != "" {
		return f.saved, f.err
	}

	return message, f.err
}

func (f fakeTestUseCase) RegisterUser(ctx context.Context, username string, password string) (domain.User, error) {
	if f.user.ID != 0 {
		return f.user, f.err
	}

	return domain.User{ID: 1, Username: username}, f.err
}

func (f fakeTestUseCase) LoginUser(ctx context.Context, username string, password string) (string, error) {
	if f.token != "" {
		return f.token, f.err
	}

	return "jwt-token", f.err
}

func (f fakeTestUseCase) CreateOrder(ctx context.Context, token string, description string) (domain.Order, error) {
	if f.order.ID != 0 {
		return f.order, f.err
	}

	return domain.Order{ID: 1, Description: description, Status: "created"}, f.err
}

func (f fakeTestUseCase) GetUserOrders(ctx context.Context, token string) ([]domain.Order, error) {
	if f.orders != nil {
		return f.orders, f.err
	}

	return []domain.Order{}, f.err
}

func TestHandleTestReturnsHello(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{message: "Hello!"})

	request := httptest.NewRequest(http.MethodGet, "/test", nil)
	response := httptest.NewRecorder()

	handler.HandleTest(response, request)

	if response.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, response.Code)
	}

	if response.Body.String() != "Hello!" {
		t.Fatalf("expected body %q, got %q", "Hello!", response.Body.String())
	}
}

func TestHandleTestRejectsUnsupportedMethod(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{message: "Hello!"})

	request := httptest.NewRequest(http.MethodPost, "/test", nil)
	response := httptest.NewRecorder()

	handler.HandleTest(response, request)

	if response.Code != http.StatusMethodNotAllowed {
		t.Fatalf("expected status %d, got %d", http.StatusMethodNotAllowed, response.Code)
	}
}

func TestHandleTestReturnsInternalServerError(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{err: errors.New("usecase error")})

	request := httptest.NewRequest(http.MethodGet, "/test", nil)
	response := httptest.NewRecorder()

	handler.HandleTest(response, request)

	if response.Code != http.StatusInternalServerError {
		t.Fatalf("expected status %d, got %d", http.StatusInternalServerError, response.Code)
	}
}

func TestHandleDBTestSavesMessage(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{saved: "saved message"})

	request := httptest.NewRequest(http.MethodPost, "/dbtest", strings.NewReader("saved message"))
	response := httptest.NewRecorder()

	handler.HandleDBTest(response, request)

	if response.Code != http.StatusCreated {
		t.Fatalf("expected status %d, got %d", http.StatusCreated, response.Code)
	}

	if response.Body.String() != "saved message" {
		t.Fatalf("expected body %q, got %q", "saved message", response.Body.String())
	}
}

func TestHandleDBTestRejectsUnsupportedMethod(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{})

	request := httptest.NewRequest(http.MethodGet, "/dbtest", nil)
	response := httptest.NewRecorder()

	handler.HandleDBTest(response, request)

	if response.Code != http.StatusMethodNotAllowed {
		t.Fatalf("expected status %d, got %d", http.StatusMethodNotAllowed, response.Code)
	}
}

func TestHandleDBTestRejectsEmptyBody(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{})

	request := httptest.NewRequest(http.MethodPost, "/dbtest", strings.NewReader("   "))
	response := httptest.NewRecorder()

	handler.HandleDBTest(response, request)

	if response.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, response.Code)
	}
}

func TestHandleDBTestReturnsInternalServerError(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{err: errors.New("save error")})

	request := httptest.NewRequest(http.MethodPost, "/dbtest", strings.NewReader("message"))
	response := httptest.NewRecorder()

	handler.HandleDBTest(response, request)

	if response.Code != http.StatusInternalServerError {
		t.Fatalf("expected status %d, got %d", http.StatusInternalServerError, response.Code)
	}
}

func TestHandleRegisterCreatesUser(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{
		user: domain.User{ID: 7, Username: "maks"},
	})

	request := httptest.NewRequest(http.MethodPost, "/register", strings.NewReader(`{"username":"maks","password":"secret"}`))
	response := httptest.NewRecorder()

	handler.HandleRegister(response, request)

	if response.Code != http.StatusCreated {
		t.Fatalf("expected status %d, got %d", http.StatusCreated, response.Code)
	}

	var body registerResponse
	if err := json.NewDecoder(response.Body).Decode(&body); err != nil {
		t.Fatalf("failed to decode response body: %v", err)
	}

	if body.ID != 7 || body.Username != "maks" {
		t.Fatalf("unexpected response body: %+v", body)
	}
}

func TestHandleRegisterRejectsDuplicateUser(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{err: usecase.ErrUserAlreadyExists})

	request := httptest.NewRequest(http.MethodPost, "/register", strings.NewReader(`{"username":"maks","password":"secret"}`))
	response := httptest.NewRecorder()

	handler.HandleRegister(response, request)

	if response.Code != http.StatusConflict {
		t.Fatalf("expected status %d, got %d", http.StatusConflict, response.Code)
	}
}

func TestHandleLoginReturnsToken(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{token: "jwt-token"})

	request := httptest.NewRequest(http.MethodPost, "/login", strings.NewReader(`{"username":"maks","password":"secret"}`))
	response := httptest.NewRecorder()

	handler.HandleLogin(response, request)

	if response.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, response.Code)
	}

	var body loginResponse
	if err := json.NewDecoder(response.Body).Decode(&body); err != nil {
		t.Fatalf("failed to decode response body: %v", err)
	}

	if body.Token != "jwt-token" {
		t.Fatalf("expected token %q, got %q", "jwt-token", body.Token)
	}
}

func TestHandleLoginRejectsInvalidCredentials(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{err: usecase.ErrInvalidCredentials})

	request := httptest.NewRequest(http.MethodPost, "/login", strings.NewReader(`{"username":"maks","password":"bad"}`))
	response := httptest.NewRecorder()

	handler.HandleLogin(response, request)

	if response.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, response.Code)
	}
}

func TestHandleCreateOrderCreatesOrder(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{
		order: domain.Order{ID: 10, Description: "new order", Status: "created"},
	})

	request := httptest.NewRequest(http.MethodPost, "/orders", strings.NewReader(`{"description":"new order"}`))
	request.Header.Set("Authorization", "Bearer jwt-token")
	response := httptest.NewRecorder()

	handler.HandleCreateOrder(response, request)

	if response.Code != http.StatusCreated {
		t.Fatalf("expected status %d, got %d", http.StatusCreated, response.Code)
	}

	var body orderResponse
	if err := json.NewDecoder(response.Body).Decode(&body); err != nil {
		t.Fatalf("failed to decode response body: %v", err)
	}

	if body.ID != 10 || body.Description != "new order" || body.Status != "created" {
		t.Fatalf("unexpected response body: %+v", body)
	}
}

func TestHandleCreateOrderRequiresToken(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{})

	request := httptest.NewRequest(http.MethodPost, "/orders", strings.NewReader(`{"description":"new order"}`))
	response := httptest.NewRecorder()

	handler.HandleCreateOrder(response, request)

	if response.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, response.Code)
	}
}

func TestHandleCreateOrderRejectsEmptyDescription(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{err: usecase.ErrInvalidOrder})

	request := httptest.NewRequest(http.MethodPost, "/orders", strings.NewReader(`{"description":"   "}`))
	request.Header.Set("Authorization", "Bearer jwt-token")
	response := httptest.NewRecorder()

	handler.HandleCreateOrder(response, request)

	if response.Code != http.StatusBadRequest {
		t.Fatalf("expected status %d, got %d", http.StatusBadRequest, response.Code)
	}
}

func TestHandleOrderStatusesReturnsOrders(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{
		orders: []domain.Order{
			{ID: 1, Description: "first", Status: "created"},
			{ID: 2, Description: "second", Status: "paid"},
		},
	})

	request := httptest.NewRequest(http.MethodGet, "/orders/statuses", nil)
	request.Header.Set("Authorization", "Bearer jwt-token")
	response := httptest.NewRecorder()

	handler.HandleOrderStatuses(response, request)

	if response.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, response.Code)
	}

	var body orderStatusesResponse
	if err := json.NewDecoder(response.Body).Decode(&body); err != nil {
		t.Fatalf("failed to decode response body: %v", err)
	}

	if len(body.Orders) != 2 {
		t.Fatalf("expected 2 orders, got %d", len(body.Orders))
	}

	if body.Orders[0].Status != "created" || body.Orders[1].Status != "paid" {
		t.Fatalf("unexpected response body: %+v", body)
	}
}

func TestHandleOrderStatusesRequiresToken(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{})

	request := httptest.NewRequest(http.MethodGet, "/orders/statuses", nil)
	response := httptest.NewRecorder()

	handler.HandleOrderStatuses(response, request)

	if response.Code != http.StatusUnauthorized {
		t.Fatalf("expected status %d, got %d", http.StatusUnauthorized, response.Code)
	}
}
