package usecase

import (
	"context"
	"strings"

	"payment-platform-server/internal/domain"
)

const defaultOrderStatus = "created"

func (u *TestUseCase) CreateOrder(ctx context.Context, token string, description string) (domain.Order, error) {
	description = strings.TrimSpace(description)
	if description == "" {
		return domain.Order{}, ErrInvalidOrder
	}

	userID, err := u.userIDFromToken(token)
	if err != nil {
		return domain.Order{}, err
	}

	return u.repository.CreateOrder(ctx, userID, description, defaultOrderStatus)
}

func (u *TestUseCase) GetUserOrders(ctx context.Context, token string) ([]domain.Order, error) {
	userID, err := u.userIDFromToken(token)
	if err != nil {
		return nil, err
	}

	return u.repository.GetOrdersByUserID(ctx, userID)
}
