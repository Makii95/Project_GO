module payment-platform-server

go 1.26
