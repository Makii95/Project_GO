package repository

import "context"

type StaticMessageRepository struct {
	message string
}

func NewStaticMessageRepository(message string) *StaticMessageRepository {
	return &StaticMessageRepository{
		message: message,
	}
}

func (r *StaticMessageRepository) GetHelloMessage(ctx context.Context) (string, error) {
	select {
	case <-ctx.Done():
		return "", ctx.Err()
	default:
		return r.message, nil
	}
}
