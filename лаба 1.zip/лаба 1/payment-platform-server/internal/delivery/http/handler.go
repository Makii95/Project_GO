package httpdelivery

import (
	"context"
	"net/http"
)

type TestUseCase interface {
	GetTestMessage(ctx context.Context) (string, error)
}
 
type TestHandler struct {
	useCase TestUseCase
}

func NewTestHandler(useCase TestUseCase) *TestHandler {
	return &TestHandler{
		useCase: useCase,
	}
}

func (h *TestHandler) RegisterRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/test", h.HandleTest)
}

func (h *TestHandler) HandleTest(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	message, err := h.useCase.GetTestMessage(r.Context())
	if err != nil {
		http.Error(w, "internal server error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write([]byte(message))
}
