package httpdelivery

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
)

type fakeTestUseCase struct {
	message string
	err     error
}

func (f fakeTestUseCase) GetTestMessage(ctx context.Context) (string, error) {
	return f.message, f.err
}

func TestHandleTestReturnsHello(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{message: "Hello!"})

	request := httptest.NewRequest(http.MethodGet, "/test", nil)
	response := httptest.NewRecorder()

	handler.HandleTest(response, request)

	if response.Code != http.StatusOK {
		t.Fatalf("expected status %d, got %d", http.StatusOK, response.Code)
	}

	if response.Body.String() != "Hello!" {
		t.Fatalf("expected body %q, got %q", "Hello!", response.Body.String())
	}
}

func TestHandleTestRejectsUnsupportedMethod(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{message: "Hello!"})

	request := httptest.NewRequest(http.MethodPost, "/test", nil)
	response := httptest.NewRecorder()

	handler.HandleTest(response, request)

	if response.Code != http.StatusMethodNotAllowed {
		t.Fatalf("expected status %d, got %d", http.StatusMethodNotAllowed, response.Code)
	}
}

func TestHandleTestReturnsInternalServerError(t *testing.T) {
	handler := NewTestHandler(fakeTestUseCase{err: errors.New("usecase error")})

	request := httptest.NewRequest(http.MethodGet, "/test", nil)
	response := httptest.NewRecorder()

	handler.HandleTest(response, request)

	if response.Code != http.StatusInternalServerError {
		t.Fatalf("expected status %d, got %d", http.StatusInternalServerError, response.Code)
	}
}
