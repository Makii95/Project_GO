package main

import (
	"context"
	"errors"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	httpdelivery "payment-platform-server/internal/delivery/http"
	"payment-platform-server/internal/repository"
	"payment-platform-server/internal/usecase"
)

const (
	serverAddress   = ":8080"
	shutdownTimeout = 10 * time.Second
)

func main() {
	logger := log.New(os.Stdout, "payment-platform-server: ", log.LstdFlags|log.Lmicroseconds)

	messageRepository := repository.NewStaticMessageRepository("Hello!")
	testUseCase := usecase.NewTestUseCase(messageRepository)
	testHandler := httpdelivery.NewTestHandler(testUseCase)

	mux := http.NewServeMux()
	testHandler.RegisterRoutes(mux)

	server := &http.Server{
		Addr:              serverAddress,
		Handler:           mux,
		ReadHeaderTimeout: 5 * time.Second,
	}

	shutdownSignal, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	serverErrors := make(chan error, 1)
	go func() {
		logger.Printf("server started on %s", serverAddress)
		if err := server.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			serverErrors <- err
			return
		}
		serverErrors <- nil
	}()

	select {
	case err := <-serverErrors:
		if err != nil {
			logger.Fatalf("server failed: %v", err)
		}
		return
	case <-shutdownSignal.Done():
		stop()
		logger.Println("shutdown signal received")
	}

	shutdownContext, cancel := context.WithTimeout(context.Background(), shutdownTimeout)
	defer cancel()

	if err := server.Shutdown(shutdownContext); err != nil {
		logger.Printf("graceful shutdown failed: %v", err)
		if closeErr := server.Close(); closeErr != nil {
			logger.Printf("forced close failed: %v", closeErr)
		}
		return
	}

	if err := <-serverErrors; err != nil {
		logger.Printf("server stopped with error: %v", err)
		return
	}

	logger.Println("server stopped gracefully")
}
