package usecase

import (
	"context"
	"log"
	"strings"

	"payment-platform-server/internal/domain"
	"payment-platform-server/internal/metrics"
)

const defaultOrderStatus = "created"

func (u *TestUseCase) CreateOrder(ctx context.Context, userID int64, description string) (domain.Order, error) {
	description = strings.TrimSpace(description)
	if description == "" {
		return domain.Order{}, ErrInvalidOrder
	}

	order, err := u.repository.CreateOrder(ctx, userID, description, defaultOrderStatus)
	if err != nil {
		return domain.Order{}, err
	}

	metrics.OrdersCreatedTotal.Inc()

	if u.publisher != nil {
		if err := u.publisher.PublishOrderCreated(ctx, order); err != nil {
			log.Printf("failed to publish order created event: %v", err)
		}
	}

	return order, nil
}

func (u *TestUseCase) GetUserOrders(ctx context.Context, userID int64) ([]domain.Order, error) {
	return u.repository.GetOrdersByUserID(ctx, userID)
}
