package broker

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	amqp "github.com/rabbitmq/amqp091-go"

	"payment-platform-server/internal/domain"
	"payment-platform-server/internal/events"
)

type RabbitMQ struct {
	connection *amqp.Connection
	channel    *amqp.Channel
}

func NewRabbitMQ(url string) (*RabbitMQ, error) {
	var lastErr error
	for attempt := 1; attempt <= 30; attempt++ {
		connection, err := amqp.Dial(url)
		if err == nil {
			channel, err := connection.Channel()
			if err != nil {
				_ = connection.Close()
				return nil, err
			}

			client := &RabbitMQ{
				connection: connection,
				channel:    channel,
			}
			if err := client.DeclareQueues(); err != nil {
				_ = client.Close()
				return nil, err
			}

			return client, nil
		}

		lastErr = err
		time.Sleep(time.Second)
	}

	return nil, fmt.Errorf("connect to rabbitmq: %w", lastErr)
}

func (r *RabbitMQ) DeclareQueues() error {
	if _, err := r.channel.QueueDeclare(events.OrderCreatedQueue, true, false, false, false, nil); err != nil {
		return err
	}

	_, err := r.channel.QueueDeclare(events.OrderStatusChangedQueue, true, false, false, false, nil)
	return err
}

func (r *RabbitMQ) PublishOrderCreated(ctx context.Context, order domain.Order) error {
	event := events.OrderCreated{
		OrderID:     order.ID,
		UserID:      order.UserID,
		Description: order.Description,
		Status:      order.Status,
	}

	return r.publish(ctx, events.OrderCreatedQueue, event)
}

func (r *RabbitMQ) PublishOrderStatusChanged(ctx context.Context, event events.OrderStatusChanged) error {
	return r.publish(ctx, events.OrderStatusChangedQueue, event)
}

func (r *RabbitMQ) ConsumeOrderCreated() (<-chan amqp.Delivery, error) {
	return r.channel.Consume(events.OrderCreatedQueue, "order-processor", false, false, false, false, nil)
}

func (r *RabbitMQ) ConsumeOrderStatusChanged() (<-chan amqp.Delivery, error) {
	return r.channel.Consume(events.OrderStatusChangedQueue, "payment-platform-server", false, false, false, false, nil)
}

func (r *RabbitMQ) Close() error {
	if r.channel != nil {
		_ = r.channel.Close()
	}
	if r.connection != nil {
		return r.connection.Close()
	}

	return nil
}

func (r *RabbitMQ) publish(ctx context.Context, queue string, event any) error {
	body, err := json.Marshal(event)
	if err != nil {
		return err
	}

	return r.channel.PublishWithContext(
		ctx,
		"",
		queue,
		false,
		false,
		amqp.Publishing{
			ContentType:  "application/json",
			DeliveryMode: amqp.Persistent,
			Body:         body,
		},
	)
}
