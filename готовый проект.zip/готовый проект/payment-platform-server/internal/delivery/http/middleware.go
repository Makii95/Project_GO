package httpdelivery

import (
	"context"
	"errors"
	"log/slog"
	"net/http"

	"payment-platform-server/internal/usecase"
)

type userIDContextKey struct{}

func (h *TestHandler) AuthMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		token, ok := bearerToken(r)
		if !ok {
			h.log.Warn("authorization token is missing", slog.String("path", r.URL.Path), slog.String("method", r.Method))
			http.Error(w, "authorization token is required", http.StatusUnauthorized)
			return
		}

		userID, err := h.useCase.UserIDFromToken(token)
		if err != nil {
			if errors.Is(err, usecase.ErrUnauthorized) {
				h.log.Warn("authorization token is invalid", slog.String("path", r.URL.Path), slog.String("method", r.Method))
				http.Error(w, "invalid authorization token", http.StatusUnauthorized)
				return
			}

			h.log.Error("authorization middleware failed", slog.String("path", r.URL.Path), slog.String("method", r.Method), slog.Any("error", err))
			http.Error(w, "internal server error", http.StatusInternalServerError)
			return
		}

		h.log.Info("authorization token accepted", slog.String("path", r.URL.Path), slog.String("method", r.Method), slog.Int64("user_id", userID))
		ctx := context.WithValue(r.Context(), userIDContextKey{}, userID)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func userIDFromContext(ctx context.Context) (int64, bool) {
	userID, ok := ctx.Value(userIDContextKey{}).(int64)
	return userID, ok && userID > 0
}
