package httpdelivery

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"os"
	"strings"

	"payment-platform-server/internal/domain"
	"payment-platform-server/internal/usecase"
)

type TestUseCase interface {
	GetTestMessage(ctx context.Context) (string, error)
	SaveDBTestMessage(ctx context.Context, message string) (string, error)
	RegisterUser(ctx context.Context, username string, password string) (domain.User, error)
	LoginUser(ctx context.Context, username string, password string) (string, error)
	UserIDFromToken(token string) (int64, error)
	CreateOrder(ctx context.Context, userID int64, description string) (domain.Order, error)
	GetUserOrders(ctx context.Context, userID int64) ([]domain.Order, error)
}

type authRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

type registerResponse struct {
	ID       int64  `json:"id"`
	Username string `json:"username"`
}

type loginResponse struct {
	Token string `json:"token"`
}

type createOrderRequest struct {
	Description string `json:"description"`
}

type orderResponse struct {
	ID          int64  `json:"id"`
	Description string `json:"description"`
	Status      string `json:"status"`
}

type orderStatusesResponse struct {
	Orders []orderResponse `json:"orders"`
}

type TestHandler struct {
	useCase TestUseCase
	log     *slog.Logger
}

func NewTestHandler(useCase TestUseCase, logger ...*slog.Logger) *TestHandler {
	log := slog.New(slog.NewJSONHandler(os.Stdout, nil))
	if len(logger) > 0 && logger[0] != nil {
		log = logger[0]
	}

	return &TestHandler{
		useCase: useCase,
		log:     log,
	}
}

func (h *TestHandler) RegisterRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/test", h.HandleTest)
	mux.HandleFunc("/dbtest", h.HandleDBTest)
	mux.HandleFunc("/register", h.HandleRegister)
	mux.HandleFunc("/login", h.HandleLogin)
	mux.Handle("/orders", h.AuthMiddleware(http.HandlerFunc(h.HandleCreateOrder)))
	mux.Handle("/orders/statuses", h.AuthMiddleware(http.HandlerFunc(h.HandleOrderStatuses)))
	mux.HandleFunc("/auth/register", h.HandleRegister)
	mux.HandleFunc("/auth/login", h.HandleLogin)
	mux.Handle("/orders/create", h.AuthMiddleware(http.HandlerFunc(h.HandleCreateOrder)))
	mux.Handle("/orders/list", h.AuthMiddleware(http.HandlerFunc(h.HandleOrderStatuses)))
}

func (h *TestHandler) HandleTest(w http.ResponseWriter, r *http.Request) {
	h.log.Info("received test request", slog.String("method", r.Method), slog.String("path", r.URL.Path))

	if r.Method != http.MethodGet {
		h.log.Warn("method not allowed", slog.String("method", r.Method), slog.String("path", r.URL.Path))
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	message, err := h.useCase.GetTestMessage(r.Context())
	if err != nil {
		h.log.Error("failed to get test message", slog.Any("error", err))
		http.Error(w, "internal server error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write([]byte(message))
}

func (h *TestHandler) HandleDBTest(w http.ResponseWriter, r *http.Request) {
	h.log.Info("received dbtest request", slog.String("method", r.Method), slog.String("path", r.URL.Path))

	if r.Method != http.MethodPost {
		h.log.Warn("method not allowed", slog.String("method", r.Method), slog.String("path", r.URL.Path))
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	body, err := io.ReadAll(io.LimitReader(r.Body, 1<<20))
	if err != nil {
		h.log.Error("failed to read dbtest body", slog.Any("error", err))
		http.Error(w, "failed to read request body", http.StatusBadRequest)
		return
	}

	message := strings.TrimSpace(string(body))
	if message == "" {
		h.log.Warn("dbtest request body is empty")
		http.Error(w, "request body is empty", http.StatusBadRequest)
		return
	}

	savedMessage, err := h.useCase.SaveDBTestMessage(r.Context(), message)
	if err != nil {
		h.log.Error("failed to save dbtest message", slog.Any("error", err))
		http.Error(w, "internal server error", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.WriteHeader(http.StatusCreated)
	_, _ = w.Write([]byte(savedMessage))
}

func (h *TestHandler) HandleRegister(w http.ResponseWriter, r *http.Request) {
	h.log.Info("received user registration request", slog.String("method", r.Method), slog.String("path", r.URL.Path))

	if r.Method != http.MethodPost {
		h.log.Warn("method not allowed", slog.String("method", r.Method), slog.String("path", r.URL.Path))
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var request authRequest
	if err := json.NewDecoder(r.Body).Decode(&request); err != nil {
		h.log.Warn("invalid register json body", slog.Any("error", err))
		http.Error(w, "invalid json body", http.StatusBadRequest)
		return
	}

	user, err := h.useCase.RegisterUser(r.Context(), request.Username, request.Password)
	if err != nil {
		switch {
		case errors.Is(err, usecase.ErrInvalidCredentials):
			h.log.Warn("register validation failed", slog.String("username", request.Username))
			http.Error(w, "username and password are required", http.StatusBadRequest)
		case errors.Is(err, usecase.ErrUserAlreadyExists):
			h.log.Warn("register user already exists", slog.String("username", request.Username))
			http.Error(w, "user already exists", http.StatusConflict)
		default:
			h.log.Error("failed to register user", slog.String("username", request.Username), slog.Any("error", err))
			http.Error(w, "internal server error", http.StatusInternalServerError)
		}
		return
	}

	h.log.Info("user registered successfully", slog.Int64("user_id", user.ID), slog.String("username", user.Username))
	writeJSON(w, http.StatusCreated, registerResponse{
		ID:       user.ID,
		Username: user.Username,
	})
}

func (h *TestHandler) HandleLogin(w http.ResponseWriter, r *http.Request) {
	h.log.Info("received login request", slog.String("method", r.Method), slog.String("path", r.URL.Path))

	if r.Method != http.MethodPost {
		h.log.Warn("method not allowed", slog.String("method", r.Method), slog.String("path", r.URL.Path))
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var request authRequest
	if err := json.NewDecoder(r.Body).Decode(&request); err != nil {
		h.log.Warn("invalid login json body", slog.Any("error", err))
		http.Error(w, "invalid json body", http.StatusBadRequest)
		return
	}

	token, err := h.useCase.LoginUser(r.Context(), request.Username, request.Password)
	if err != nil {
		if errors.Is(err, usecase.ErrInvalidCredentials) {
			h.log.Warn("invalid login credentials", slog.String("username", request.Username))
			http.Error(w, "invalid username or password", http.StatusUnauthorized)
			return
		}

		h.log.Error("failed to login user", slog.String("username", request.Username), slog.Any("error", err))
		http.Error(w, "internal server error", http.StatusInternalServerError)
		return
	}

	h.log.Info("user logged in successfully", slog.String("username", request.Username))
	writeJSON(w, http.StatusOK, loginResponse{Token: token})
}

func (h *TestHandler) HandleCreateOrder(w http.ResponseWriter, r *http.Request) {
	h.log.Info("received create order request", slog.String("method", r.Method), slog.String("path", r.URL.Path))

	if r.Method != http.MethodPost {
		h.log.Warn("method not allowed", slog.String("method", r.Method), slog.String("path", r.URL.Path))
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	userID, ok := userIDFromContext(r.Context())
	if !ok {
		h.log.Warn("create order request has no user id")
		http.Error(w, "user id is required", http.StatusUnauthorized)
		return
	}

	var request createOrderRequest
	if err := json.NewDecoder(r.Body).Decode(&request); err != nil {
		h.log.Warn("invalid create order json body", slog.Int64("user_id", userID), slog.Any("error", err))
		http.Error(w, "invalid json body", http.StatusBadRequest)
		return
	}

	order, err := h.useCase.CreateOrder(r.Context(), userID, request.Description)
	if err != nil {
		switch {
		case errors.Is(err, usecase.ErrInvalidOrder):
			h.log.Warn("order validation failed", slog.Int64("user_id", userID))
			http.Error(w, "order description is required", http.StatusBadRequest)
		default:
			h.log.Error("failed to create order", slog.Int64("user_id", userID), slog.Any("error", err))
			http.Error(w, "internal server error", http.StatusInternalServerError)
		}
		return
	}

	h.log.Info("order created successfully", slog.Int64("user_id", userID), slog.Int64("order_id", order.ID), slog.String("status", order.Status))
	writeJSON(w, http.StatusCreated, orderResponse{
		ID:          order.ID,
		Description: order.Description,
		Status:      order.Status,
	})
}

func (h *TestHandler) HandleOrderStatuses(w http.ResponseWriter, r *http.Request) {
	h.log.Info("received order statuses request", slog.String("method", r.Method), slog.String("path", r.URL.Path))

	if r.Method != http.MethodGet {
		h.log.Warn("method not allowed", slog.String("method", r.Method), slog.String("path", r.URL.Path))
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	userID, ok := userIDFromContext(r.Context())
	if !ok {
		h.log.Warn("order statuses request has no user id")
		http.Error(w, "user id is required", http.StatusUnauthorized)
		return
	}

	orders, err := h.useCase.GetUserOrders(r.Context(), userID)
	if err != nil {
		h.log.Error("failed to get user orders", slog.Int64("user_id", userID), slog.Any("error", err))
		http.Error(w, "internal server error", http.StatusInternalServerError)
		return
	}

	response := orderStatusesResponse{
		Orders: make([]orderResponse, 0, len(orders)),
	}
	for _, order := range orders {
		response.Orders = append(response.Orders, orderResponse{
			ID:          order.ID,
			Description: order.Description,
			Status:      order.Status,
		})
	}

	h.log.Info("order statuses returned", slog.Int64("user_id", userID), slog.Int("orders_count", len(orders)))
	writeJSON(w, http.StatusOK, response)
}

func writeJSON(w http.ResponseWriter, statusCode int, value any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(statusCode)
	_ = json.NewEncoder(w).Encode(value)
}

func bearerToken(r *http.Request) (string, bool) {
	header := strings.TrimSpace(r.Header.Get("Authorization"))
	if header == "" {
		return "", false
	}

	const prefix = "Bearer "
	if !strings.HasPrefix(header, prefix) {
		return "", false
	}

	token := strings.TrimSpace(strings.TrimPrefix(header, prefix))
	return token, token != ""
}
