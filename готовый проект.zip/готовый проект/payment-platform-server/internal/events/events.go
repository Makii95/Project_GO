package events

const (
	OrderCreatedQueue       = "orders.created"
	OrderStatusChangedQueue = "orders.status_changed"
)

type OrderCreated struct {
	OrderID     int64  `json:"order_id"`
	UserID      int64  `json:"user_id"`
	Description string `json:"description"`
	Status      string `json:"status"`
}

type OrderStatusChanged struct {
	OrderID int64  `json:"order_id"`
	Status  string `json:"status"`
}
