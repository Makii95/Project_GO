const state = {
  token: localStorage.getItem("payment_platform_token") || "",
  username: localStorage.getItem("payment_platform_username") || "",
};

const elements = {
  username: document.querySelector("#username"),
  password: document.querySelector("#password"),
  tokenOutput: document.querySelector("#token-output"),
  tokenBox: document.querySelector("#token-box"),
  orderDescription: document.querySelector("#order-description"),
  orders: document.querySelector("#orders"),
  ordersCount: document.querySelector("#orders-count"),
  createdCount: document.querySelector("#created-count"),
  processedCount: document.querySelector("#processed-count"),
  log: document.querySelector("#log"),
  serverStatus: document.querySelector("#server-status"),
  serverPulse: document.querySelector("#server-pulse"),
  authStatus: document.querySelector("#auth-status"),
  authDot: document.querySelector("#auth-dot"),
  brandMark: document.querySelector("#brand-mark"),
  paymentAmount: document.querySelector("#payment-amount"),
  toast: document.querySelector("#toast"),
};

document.querySelector("#fill-demo-btn").addEventListener("click", fillDemo);
document.querySelector("#clear-btn").addEventListener("click", clearForm);
document.querySelector("#logout-btn").addEventListener("click", logout);
document.querySelector("#register-btn").addEventListener("click", registerUser);
document.querySelector("#login-btn").addEventListener("click", loginUser);
document.querySelector("#copy-token-btn").addEventListener("click", copyToken);
document.querySelector("#sample-order-btn").addEventListener("click", fillSampleOrder);
document.querySelector("#create-order-btn").addEventListener("click", createOrder);
document.querySelector("#load-orders-btn").addEventListener("click", loadOrders);
document.querySelector("#dbtest-btn").addEventListener("click", dbTest);

elements.username.value = state.username;
renderAuthState();
checkServer();

if (state.token) {
  loadOrders();
}

async function checkServer() {
  const result = await request("/test", { method: "GET" }, { silent: true });
  const ok = result.ok && result.data === "Hello!";
  elements.serverStatus.textContent = ok ? "Работает, /test вернул Hello!" : "Сервер ответил, но /test не прошел";
  elements.serverPulse.classList.toggle("ok", ok);
  elements.serverPulse.classList.toggle("fail", !ok);

  if (!result.ok) {
    elements.serverStatus.textContent = "Сервер недоступен";
    elements.serverPulse.classList.add("fail");
    addLog("Ошибка проверки сервера", result.data);
  }
}

function fillDemo() {
  const suffix = Math.floor(Math.random() * 10000);
  elements.username.value = `demo_${suffix}`;
  elements.password.value = "secret123";
  elements.paymentAmount.value = String(Math.floor(Math.random() * 9000) + 1000);
  elements.orderDescription.value = `Оплата продукта PulsePay #${suffix}`;
  toast("Демо-данные заполнены");
}

function clearForm() {
  elements.username.value = "";
  elements.password.value = "";
  elements.paymentAmount.value = "";
  elements.orderDescription.value = "";
  toast("Поля очищены");
}

async function registerUser() {
  const body = credentials();
  if (!body) return;

  const result = await request("/register", {
    method: "POST",
    headers: jsonHeaders(),
    body: JSON.stringify(body),
  });

  if (!result.ok) return;

  addLog("Пользователь зарегистрирован", result.data);
  toast("Пользователь создан. Теперь можно войти.");
}

async function loginUser() {
  const body = credentials();
  if (!body) return;

  const result = await request("/login", {
    method: "POST",
    headers: jsonHeaders(),
    body: JSON.stringify(body),
  });

  if (!result.ok) return;

  state.token = result.data.token;
  state.username = body.username;
  localStorage.setItem("payment_platform_token", state.token);
  localStorage.setItem("payment_platform_username", state.username);
  renderAuthState();
  addLog("Вход выполнен, JWT сохранен", { username: state.username, token: shortToken(state.token) });
  celebrate(elements.authDot);
  toast("Вход выполнен");
  await loadOrders();
}

function logout() {
  state.token = "";
  state.username = "";
  localStorage.removeItem("payment_platform_token");
  localStorage.removeItem("payment_platform_username");
  renderAuthState();
  renderOrders([]);
  addLog("Выход выполнен", "JWT удален из браузера");
  celebrate(elements.brandMark);
  toast("JWT удален");
}

async function copyToken() {
  if (!state.token) {
    toast("Сначала войди, чтобы получить JWT");
    return;
  }

  try {
    await navigator.clipboard.writeText(state.token);
    toast("JWT скопирован");
  } catch {
    addLog("Не удалось скопировать JWT", state.token);
    toast("JWT показан в журнале");
  }
}

function fillSampleOrder() {
  elements.paymentAmount.value = String(Math.floor(Math.random() * 9000) + 1000);
  elements.orderDescription.value = `Оплата подписки Premium #${Math.floor(Math.random() * 9000) + 1000}`;
  toast("Пример платежа заполнен");
}

async function createOrder() {
  if (!requireToken()) return;

  const description = elements.orderDescription.value.trim();
  const amount = elements.paymentAmount.value.trim();
  if (!description) {
    addLog("Платеж не создан", "Заполни назначение платежа");
    toast("Нужно назначение платежа");
    return;
  }

  const paymentDescription = amount ? `${description}. Сумма: ${amount} ₽` : description;
  const result = await request("/orders", {
    method: "POST",
    headers: jsonHeaders(true),
    body: JSON.stringify({ description: paymentDescription }),
  });

  if (!result.ok) return;

  elements.paymentAmount.value = "";
  elements.orderDescription.value = "";
  addLog("Платеж создан", result.data);
  celebrate(elements.ordersCount);
  toast("Платеж создан");
  await loadOrders();
}

async function loadOrders() {
  if (!requireToken()) return;

  const result = await request("/orders/statuses", {
    method: "GET",
    headers: authHeaders(),
  });

  if (!result.ok) return;

  renderOrders(result.data.orders || []);
  addLog("Список платежей получен", result.data);
}

async function dbTest() {
  const message = `frontend check ${new Date().toLocaleString("ru-RU")}`;
  const result = await request("/dbtest", {
    method: "POST",
    headers: { "Content-Type": "text/plain; charset=utf-8" },
    body: message,
  });

  if (!result.ok) return;

  addLog("/dbtest записал строку в БД", result.data);
  toast("/dbtest работает");
}

async function request(url, options, settings = {}) {
  try {
    const response = await fetch(url, options);
    const data = await parseResponse(response);
    if (!response.ok) {
      const readableError = humanError(response.status, data);
      if (!settings.silent) {
        addLog(`Ошибка ${response.status} ${url}`, readableError);
        toast(readableError);
      }
      return { ok: false, data: readableError };
    }

    return { ok: true, data };
  } catch (error) {
    if (!settings.silent) {
      addLog(`Сетевая ошибка ${url}`, error.message);
      toast("Сервер недоступен");
    }
    return { ok: false, data: error.message };
  }
}

async function parseResponse(response) {
  const contentType = response.headers.get("Content-Type") || "";
  if (contentType.includes("application/json")) {
    return response.json();
  }

  return response.text();
}

function humanError(status, data) {
  const text = typeof data === "string" ? data.trim() : JSON.stringify(data);
  if (status === 400) return text || "Некорректный запрос";
  if (status === 401) return "Нужно войти заново или JWT неверный";
  if (status === 409) return "Такой пользователь уже существует. Попробуй войти.";
  if (status === 405) return "Этот метод запроса не поддерживается";
  if (status >= 500) return "Ошибка сервера. Проверь терминал с Go.";
  return text || "Неизвестная ошибка";
}

function credentials() {
  const username = elements.username.value.trim();
  const password = elements.password.value.trim();
  if (!username || !password) {
    addLog("Не хватает данных", "Заполни логин и пароль");
    toast("Заполни логин и пароль");
    return null;
  }

  return { username, password };
}

function requireToken() {
  if (state.token) return true;

  addLog("JWT токен отсутствует", "Сначала выполни вход пользователя");
  toast("Сначала войди");
  return false;
}

function jsonHeaders(withAuth = false) {
  return {
    "Content-Type": "application/json",
    ...(withAuth ? authHeaders() : {}),
  };
}

function authHeaders() {
  return {
    Authorization: `Bearer ${state.token}`,
  };
}

function renderAuthState() {
  const hasToken = Boolean(state.token);
  elements.tokenOutput.textContent = hasToken ? state.token : "токен появится после входа";
  elements.tokenBox.classList.toggle("active", hasToken);
  elements.authDot.classList.toggle("ok", hasToken);
  elements.authStatus.textContent = hasToken ? `Вошел: ${state.username || "пользователь"}` : "Пользователь не вошел";
  elements.brandMark.textContent = hasToken ? initials(state.username) : "PP";
}

function renderOrders(orders) {
  const created = orders.filter((order) => order.status === "created").length;
  const processed = orders.filter((order) => order.status === "processed").length;

  elements.ordersCount.textContent = String(orders.length);
  elements.createdCount.textContent = String(created);
  elements.processedCount.textContent = String(processed);

  if (!orders.length) {
    elements.orders.className = "orders empty";
    elements.orders.textContent = state.token ? "У этого пользователя пока нет платежей." : "Войди и создай первый платеж.";
    return;
  }

  elements.orders.className = "orders";
  elements.orders.innerHTML = orders.map((order) => `
    <div class="order">
      <div class="order-id">#${escapeHTML(String(order.id))}</div>
      <div>
        <strong>${escapeHTML(order.description)}</strong>
        <p>Платеж принадлежит текущему пользователю</p>
      </div>
      <span class="badge ${escapeHTML(order.status)}">${escapeHTML(order.status)}</span>
    </div>
  `).join("");
}

function addLog(title, payload) {
  const entry = {
    time: new Date().toLocaleTimeString("ru-RU"),
    title,
    payload,
  };
  elements.log.textContent = `${elements.log.textContent}\n\n${JSON.stringify(entry, null, 2)}`.trim();
  elements.log.scrollTop = elements.log.scrollHeight;
  elements.log.classList.remove("updated");
  void elements.log.offsetWidth;
  elements.log.classList.add("updated");
}

function toast(message) {
  elements.toast.textContent = message;
  elements.toast.hidden = false;
  elements.toast.classList.remove("show");
  void elements.toast.offsetWidth;
  elements.toast.classList.add("show");
  window.clearTimeout(toast.timer);
  toast.timer = window.setTimeout(() => {
    elements.toast.hidden = true;
    elements.toast.classList.remove("show");
  }, 2600);
}

function celebrate(element) {
  if (!element) return;

  element.classList.remove("celebrate");
  void element.offsetWidth;
  element.classList.add("celebrate");
  window.setTimeout(() => element.classList.remove("celebrate"), 700);
}

function initials(username) {
  const clean = (username || "").trim();
  if (!clean) return "PP";

  return clean.slice(0, 2).toUpperCase();
}

function shortToken(token) {
  if (token.length <= 32) return token;
  return `${token.slice(0, 24)}...${token.slice(-16)}`;
}

function escapeHTML(value) {
  return value.replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;",
  }[char]));
}
