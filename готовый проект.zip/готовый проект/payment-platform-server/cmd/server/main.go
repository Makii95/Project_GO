package main

import (
	"context"
	"database/sql"
	"embed"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	_ "github.com/lib/pq"
	"github.com/prometheus/client_golang/prometheus/promhttp"

	"payment-platform-server/internal/broker"
	httpdelivery "payment-platform-server/internal/delivery/http"
	"payment-platform-server/internal/events"
	"payment-platform-server/internal/metrics"
	"payment-platform-server/internal/repository"
	"payment-platform-server/internal/usecase"
)

//go:embed web
var frontendFiles embed.FS

const (
	defaultAddress  = ":8080"
	shutdownTimeout = 10 * time.Second
)

type databaseConfig struct {
	host     string
	port     string
	user     string
	password string
	name     string
	sslMode  string
}

func main() {
	logger := slog.New(slog.NewJSONHandler(os.Stdout, nil))

	dbConfig := loadDatabaseConfig()

	db, err := sql.Open("postgres", dbConfig.connectionString())
	if err != nil {
		logger.Error("failed to open database connection", slog.Any("error", err))
		os.Exit(1)
	}
	defer func() {
		if closeErr := db.Close(); closeErr != nil {
			logger.Error("failed to close database connection", slog.Any("error", closeErr))
		}
	}()

	pingContext, cancelPing := context.WithTimeout(context.Background(), 5*time.Second)
	if err := db.PingContext(pingContext); err != nil {
		cancelPing()
		logger.Error("failed to connect to database", slog.Any("error", err))
		os.Exit(1)
	}
	cancelPing()
	logger.Info("database connection established", slog.String("host", dbConfig.host), slog.String("database", dbConfig.name))

	messageRepository := repository.NewPostgresMessageRepository(db, "Hello!")
	initContext, cancelInit := context.WithTimeout(context.Background(), 5*time.Second)
	if err := messageRepository.InitSchema(initContext); err != nil {
		cancelInit()
		logger.Error("failed to initialize database schema", slog.Any("error", err))
		os.Exit(1)
	}
	cancelInit()
	logger.Info("database schema initialized")

	testUseCase := usecase.NewTestUseCase(messageRepository, getEnv("JWT_SECRET", "local-development-secret"))

	rabbit, err := broker.NewRabbitMQ(getEnv("RABBITMQ_URL", "amqp://guest:guest@localhost:5672/"))
	if err != nil {
		logger.Warn("rabbitmq is unavailable, order events are disabled", slog.Any("error", err))
	} else {
		defer func() {
			if closeErr := rabbit.Close(); closeErr != nil {
				logger.Error("failed to close rabbitmq connection", slog.Any("error", closeErr))
			}
		}()
		testUseCase.SetOrderPublisher(rabbit)
		go consumeOrderStatusChanges(context.Background(), logger, rabbit, messageRepository)
		logger.Info("rabbitmq connection established")
	}

	testHandler := httpdelivery.NewTestHandler(testUseCase, logger)

	mux := http.NewServeMux()
	testHandler.RegisterRoutes(mux)
	mux.Handle("/metrics", promhttp.Handler())
	registerFrontend(mux, logger)

	serverAddress := getEnv("SERVER_ADDRESS", defaultAddress)
	server := &http.Server{
		Addr:              serverAddress,
		Handler:           metrics.HTTPMiddleware(mux),
		ReadHeaderTimeout: 5 * time.Second,
	}

	shutdownSignal, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	serverErrors := make(chan error, 1)
	go func() {
		logger.Info("server started", slog.String("address", serverAddress))
		if err := server.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			serverErrors <- err
			return
		}
		serverErrors <- nil
	}()

	select {
	case err := <-serverErrors:
		if err != nil {
			logger.Error("server failed", slog.Any("error", err))
			os.Exit(1)
		}
		return
	case <-shutdownSignal.Done():
		stop()
		logger.Info("shutdown signal received")
	}

	shutdownContext, cancel := context.WithTimeout(context.Background(), shutdownTimeout)
	defer cancel()

	if err := server.Shutdown(shutdownContext); err != nil {
		logger.Error("graceful shutdown failed", slog.Any("error", err))
		if closeErr := server.Close(); closeErr != nil {
			logger.Error("forced close failed", slog.Any("error", closeErr))
		}
		return
	}

	if err := <-serverErrors; err != nil {
		logger.Error("server stopped with error", slog.Any("error", err))
		return
	}

	logger.Info("server stopped gracefully")
}

func registerFrontend(mux *http.ServeMux, logger *slog.Logger) {
	webFiles, err := fs.Sub(frontendFiles, "web")
	if err != nil {
		logger.Error("failed to load embedded frontend", slog.Any("error", err))
		return
	}

	fileServer := http.FileServer(http.FS(webFiles))
	mux.Handle("/", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
		w.Header().Set("Pragma", "no-cache")
		fileServer.ServeHTTP(w, r)
	}))
	logger.Info("frontend registered")
}

func loadDatabaseConfig() databaseConfig {
	return databaseConfig{
		host:     getEnv("DB_HOST", "localhost"),
		port:     getEnv("DB_PORT", "5432"),
		user:     getEnv("DB_USER", "postgres"),
		password: getEnv("DB_PASSWORD", "postgres"),
		name:     getEnv("DB_NAME", "payment_platform"),
		sslMode:  getEnv("DB_SSLMODE", "disable"),
	}
}

func (c databaseConfig) connectionString() string {
	return fmt.Sprintf(
		"host=%s port=%s user=%s password=%s dbname=%s sslmode=%s",
		c.host,
		c.port,
		c.user,
		c.password,
		c.name,
		c.sslMode,
	)
}

func getEnv(key string, fallback string) string {
	value := os.Getenv(key)
	if value == "" {
		return fallback
	}

	return value
}

func consumeOrderStatusChanges(ctx context.Context, logger *slog.Logger, rabbit *broker.RabbitMQ, repository *repository.PostgresMessageRepository) {
	deliveries, err := rabbit.ConsumeOrderStatusChanged()
	if err != nil {
		logger.Error("failed to consume order status changed events", slog.Any("error", err))
		return
	}

	for {
		select {
		case <-ctx.Done():
			return
		case delivery, ok := <-deliveries:
			if !ok {
				return
			}

			var event events.OrderStatusChanged
			if err := json.Unmarshal(delivery.Body, &event); err != nil {
				logger.Error("failed to decode order status event", slog.Any("error", err))
				_ = delivery.Nack(false, false)
				continue
			}

			if err := repository.UpdateOrderStatus(context.Background(), event.OrderID, event.Status); err != nil {
				logger.Error("failed to update order status", slog.Int64("order_id", event.OrderID), slog.String("status", event.Status), slog.Any("error", err))
				_ = delivery.Nack(false, true)
				continue
			}

			metrics.OrderStatusChangedTotal.WithLabelValues(event.Status).Inc()
			logger.Info("order status updated", slog.Int64("order_id", event.OrderID), slog.String("status", event.Status))
			_ = delivery.Ack(false)
		}
	}
}
