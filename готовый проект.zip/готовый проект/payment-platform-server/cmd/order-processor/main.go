package main

import (
	"context"
	"encoding/json"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/prometheus/client_golang/prometheus/promhttp"

	"payment-platform-server/internal/broker"
	"payment-platform-server/internal/events"
	"payment-platform-server/internal/metrics"
)

const defaultProcessorMetricsAddress = ":9091"

func main() {
	logger := slog.New(slog.NewJSONHandler(os.Stdout, nil))

	rabbit, err := broker.NewRabbitMQ(getEnv("RABBITMQ_URL", "amqp://guest:guest@localhost:5672/"))
	if err != nil {
		logger.Error("failed to connect to rabbitmq", slog.Any("error", err))
		os.Exit(1)
	}
	defer func() {
		if closeErr := rabbit.Close(); closeErr != nil {
			logger.Error("failed to close rabbitmq connection", slog.Any("error", closeErr))
		}
	}()

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	go serveMetrics(logger, getEnv("PROCESSOR_METRICS_ADDRESS", defaultProcessorMetricsAddress))

	deliveries, err := rabbit.ConsumeOrderCreated()
	if err != nil {
		logger.Error("failed to consume created orders", slog.Any("error", err))
		os.Exit(1)
	}

	logger.Info("waiting for order events")
	for {
		select {
		case <-ctx.Done():
			logger.Info("processor stopped")
			return
		case delivery, ok := <-deliveries:
			if !ok {
				logger.Warn("order queue closed")
				return
			}

			var event events.OrderCreated
			if err := json.Unmarshal(delivery.Body, &event); err != nil {
				logger.Error("failed to decode order event", slog.Any("error", err))
				_ = delivery.Nack(false, false)
				continue
			}

			logger.Info("order event received", slog.Int64("order_id", event.OrderID), slog.Int64("user_id", event.UserID), slog.String("status", event.Status))
			time.Sleep(2 * time.Second)
			statusChanged := events.OrderStatusChanged{
				OrderID: event.OrderID,
				Status:  "processed",
			}

			if err := rabbit.PublishOrderStatusChanged(context.Background(), statusChanged); err != nil {
				logger.Error("failed to publish status event", slog.Int64("order_id", event.OrderID), slog.Any("error", err))
				_ = delivery.Nack(false, true)
				continue
			}

			metrics.OrderProcessorHandledTotal.WithLabelValues(statusChanged.Status).Inc()
			logger.Info("order processed", slog.Int64("order_id", event.OrderID), slog.String("status", statusChanged.Status))
			_ = delivery.Ack(false)
		}
	}
}

func serveMetrics(logger *slog.Logger, address string) {
	mux := http.NewServeMux()
	mux.Handle("/metrics", promhttp.Handler())

	logger.Info("metrics server started", slog.String("address", address))
	if err := http.ListenAndServe(address, mux); err != nil {
		logger.Error("metrics server stopped", slog.Any("error", err))
	}
}

func getEnv(key string, fallback string) string {
	value := os.Getenv(key)
	if value == "" {
		return fallback
	}

	return value
}
