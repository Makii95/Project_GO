package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"os"
	"strconv"
	"time"
)

type loginResponse struct {
	Token string `json:"token"`
}

func main() {
	logger := slog.New(slog.NewJSONHandler(os.Stdout, nil))

	baseURL := getEnv("TARGET_BASE_URL", "http://payment-server:8080")
	username := getEnv("LOAD_USERNAME", "load_user")
	password := getEnv("LOAD_PASSWORD", "secret123")
	interval := getDurationEnv("LOAD_INTERVAL", 2*time.Second)

	client := &http.Client{Timeout: 10 * time.Second}
	logger.Info("load generator started", slog.String("base_url", baseURL), slog.String("username", username), slog.Duration("interval", interval))

	for {
		if err := ensureUser(client, baseURL, username, password); err != nil {
			logger.Error("register user failed", slog.String("username", username), slog.Any("error", err))
			time.Sleep(interval)
			continue
		}

		token, err := login(client, baseURL, username, password)
		if err != nil {
			logger.Error("login failed", slog.String("username", username), slog.Any("error", err))
			time.Sleep(interval)
			continue
		}
		logger.Info("load user logged in", slog.String("username", username))

		counter := 1
		for {
			description := fmt.Sprintf("load order %d", counter)
			if err := createOrder(client, baseURL, token, description); err != nil {
				logger.Error("create order failed", slog.Int("order_number", counter), slog.Any("error", err))
				break
			}

			if err := getStatuses(client, baseURL, token); err != nil {
				logger.Error("get statuses failed", slog.Any("error", err))
				break
			}

			logger.Info("load order created", slog.Int("order_number", counter))
			counter++
			time.Sleep(interval)
		}
	}
}

func ensureUser(client *http.Client, baseURL string, username string, password string) error {
	body := map[string]string{"username": username, "password": password}
	response, err := postJSON(client, baseURL+"/register", body, "")
	if err != nil {
		return err
	}
	defer response.Body.Close()

	if response.StatusCode == http.StatusCreated || response.StatusCode == http.StatusConflict {
		return nil
	}

	data, _ := io.ReadAll(response.Body)
	return fmt.Errorf("unexpected register status %d: %s", response.StatusCode, string(data))
}

func login(client *http.Client, baseURL string, username string, password string) (string, error) {
	body := map[string]string{"username": username, "password": password}
	response, err := postJSON(client, baseURL+"/login", body, "")
	if err != nil {
		return "", err
	}
	defer response.Body.Close()

	if response.StatusCode != http.StatusOK {
		data, _ := io.ReadAll(response.Body)
		return "", fmt.Errorf("unexpected login status %d: %s", response.StatusCode, string(data))
	}

	var result loginResponse
	if err := json.NewDecoder(response.Body).Decode(&result); err != nil {
		return "", err
	}

	return result.Token, nil
}

func createOrder(client *http.Client, baseURL string, token string, description string) error {
	body := map[string]string{"description": description}
	response, err := postJSON(client, baseURL+"/orders", body, token)
	if err != nil {
		return err
	}
	defer response.Body.Close()

	if response.StatusCode != http.StatusCreated {
		data, _ := io.ReadAll(response.Body)
		return fmt.Errorf("unexpected create order status %d: %s", response.StatusCode, string(data))
	}

	return nil
}

func getStatuses(client *http.Client, baseURL string, token string) error {
	request, err := http.NewRequest(http.MethodGet, baseURL+"/orders/statuses", nil)
	if err != nil {
		return err
	}
	request.Header.Set("Authorization", "Bearer "+token)

	response, err := client.Do(request)
	if err != nil {
		return err
	}
	defer response.Body.Close()

	if response.StatusCode != http.StatusOK {
		data, _ := io.ReadAll(response.Body)
		return fmt.Errorf("unexpected statuses status %d: %s", response.StatusCode, string(data))
	}

	return nil
}

func postJSON(client *http.Client, url string, body any, token string) (*http.Response, error) {
	data, err := json.Marshal(body)
	if err != nil {
		return nil, err
	}

	request, err := http.NewRequest(http.MethodPost, url, bytes.NewReader(data))
	if err != nil {
		return nil, err
	}
	request.Header.Set("Content-Type", "application/json")
	if token != "" {
		request.Header.Set("Authorization", "Bearer "+token)
	}

	return client.Do(request)
}

func getEnv(key string, fallback string) string {
	value := os.Getenv(key)
	if value == "" {
		return fallback
	}

	return value
}

func getDurationEnv(key string, fallback time.Duration) time.Duration {
	value := os.Getenv(key)
	if value == "" {
		return fallback
	}

	seconds, err := strconv.Atoi(value)
	if err != nil || seconds <= 0 {
		return fallback
	}

	return time.Duration(seconds) * time.Second
}
