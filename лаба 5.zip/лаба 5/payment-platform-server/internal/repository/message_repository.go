package repository

import (
	"context"
	"database/sql"
	"errors"

	"github.com/lib/pq"

	"payment-platform-server/internal/domain"
	"payment-platform-server/internal/usecase"
)

type PostgresMessageRepository struct {
	db      *sql.DB
	message string
}

func NewPostgresMessageRepository(db *sql.DB, message string) *PostgresMessageRepository {
	return &PostgresMessageRepository{
		db:      db,
		message: message,
	}
}

func (r *PostgresMessageRepository) InitSchema(ctx context.Context) error {
	const testMessagesQuery = `
		CREATE TABLE IF NOT EXISTS test_messages (
			id SERIAL PRIMARY KEY,
			message TEXT NOT NULL,
			created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
		)
	`

	if _, err := r.db.ExecContext(ctx, testMessagesQuery); err != nil {
		return err
	}

	const usersQuery = `
		CREATE TABLE IF NOT EXISTS users (
			id SERIAL PRIMARY KEY,
			username TEXT NOT NULL UNIQUE,
			password_hash TEXT NOT NULL,
			created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
		)
	`

	if _, err := r.db.ExecContext(ctx, usersQuery); err != nil {
		return err
	}

	const ordersQuery = `
		CREATE TABLE IF NOT EXISTS orders (
			id SERIAL PRIMARY KEY,
			user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
			description TEXT NOT NULL,
			status TEXT NOT NULL,
			created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
		)
	`

	_, err := r.db.ExecContext(ctx, ordersQuery)
	return err
}

func (r *PostgresMessageRepository) GetHelloMessage(ctx context.Context) (string, error) {
	select {
	case <-ctx.Done():
		return "", ctx.Err()
	default:
		return r.message, nil
	}
}

func (r *PostgresMessageRepository) SaveMessage(ctx context.Context, message string) (string, error) {
	const query = `
		INSERT INTO test_messages (message)
		VALUES ($1)
		RETURNING message
	`

	var savedMessage string
	err := r.db.QueryRowContext(ctx, query, message).Scan(&savedMessage)
	if err != nil {
		return "", err
	}

	return savedMessage, nil
}

func (r *PostgresMessageRepository) CreateUser(ctx context.Context, username string, passwordHash string) (domain.User, error) {
	const query = `
		INSERT INTO users (username, password_hash)
		VALUES ($1, $2)
		RETURNING id, username, password_hash, created_at
	`

	var user domain.User
	err := r.db.QueryRowContext(ctx, query, username, passwordHash).
		Scan(&user.ID, &user.Username, &user.PasswordHash, &user.CreatedAt)
	if err != nil {
		var pqErr *pq.Error
		if errors.As(err, &pqErr) && pqErr.Code == "23505" {
			return domain.User{}, usecase.ErrUserAlreadyExists
		}

		return domain.User{}, err
	}

	return user, nil
}

func (r *PostgresMessageRepository) GetUserByUsername(ctx context.Context, username string) (domain.User, error) {
	const query = `
		SELECT id, username, password_hash, created_at
		FROM users
		WHERE username = $1
	`

	var user domain.User
	err := r.db.QueryRowContext(ctx, query, username).
		Scan(&user.ID, &user.Username, &user.PasswordHash, &user.CreatedAt)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return domain.User{}, usecase.ErrInvalidCredentials
		}

		return domain.User{}, err
	}

	return user, nil
}

func (r *PostgresMessageRepository) CreateOrder(ctx context.Context, userID int64, description string, status string) (domain.Order, error) {
	const query = `
		INSERT INTO orders (user_id, description, status)
		VALUES ($1, $2, $3)
		RETURNING id, user_id, description, status, created_at
	`

	var order domain.Order
	err := r.db.QueryRowContext(ctx, query, userID, description, status).
		Scan(&order.ID, &order.UserID, &order.Description, &order.Status, &order.CreatedAt)
	if err != nil {
		return domain.Order{}, err
	}

	return order, nil
}

func (r *PostgresMessageRepository) GetOrdersByUserID(ctx context.Context, userID int64) ([]domain.Order, error) {
	const query = `
		SELECT id, user_id, description, status, created_at
		FROM orders
		WHERE user_id = $1
		ORDER BY id
	`

	rows, err := r.db.QueryContext(ctx, query, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	orders := make([]domain.Order, 0)
	for rows.Next() {
		var order domain.Order
		if err := rows.Scan(&order.ID, &order.UserID, &order.Description, &order.Status, &order.CreatedAt); err != nil {
			return nil, err
		}

		orders = append(orders, order)
	}

	if err := rows.Err(); err != nil {
		return nil, err
	}

	return orders, nil
}
