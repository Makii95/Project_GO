package usecase

import (
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"payment-platform-server/internal/domain"
)

var (
	ErrInvalidCredentials = errors.New("invalid credentials")
	ErrUserAlreadyExists  = errors.New("user already exists")
	ErrUnauthorized       = errors.New("unauthorized")
	ErrInvalidOrder       = errors.New("invalid order")
)

type jwtHeader struct {
	Algorithm string `json:"alg"`
	Type      string `json:"typ"`
}

type jwtClaims struct {
	Subject   string `json:"sub"`
	Username  string `json:"username"`
	ExpiresAt int64  `json:"exp"`
	IssuedAt  int64  `json:"iat"`
}

func (u *TestUseCase) RegisterUser(ctx context.Context, username string, password string) (domain.User, error) {
	username = strings.TrimSpace(username)
	if username == "" || password == "" {
		return domain.User{}, ErrInvalidCredentials
	}

	passwordHash, err := hashPassword(password)
	if err != nil {
		return domain.User{}, err
	}

	return u.repository.CreateUser(ctx, username, passwordHash)
}

func (u *TestUseCase) LoginUser(ctx context.Context, username string, password string) (string, error) {
	username = strings.TrimSpace(username)
	if username == "" || password == "" {
		return "", ErrInvalidCredentials
	}

	user, err := u.repository.GetUserByUsername(ctx, username)
	if err != nil {
		return "", err
	}

	if !checkPassword(password, user.PasswordHash) {
		return "", ErrInvalidCredentials
	}

	return generateJWT(user, u.jwtSecret, time.Now().Add(24*time.Hour))
}

func (u *TestUseCase) UserIDFromToken(token string) (int64, error) {
	return u.userIDFromToken(token)
}

func hashPassword(password string) (string, error) {
	salt := make([]byte, 16)
	if _, err := rand.Read(salt); err != nil {
		return "", err
	}

	hash := passwordHash(password, salt)
	return hex.EncodeToString(salt) + ":" + hex.EncodeToString(hash), nil
}

func checkPassword(password string, storedHash string) bool {
	parts := strings.Split(storedHash, ":")
	if len(parts) != 2 {
		return false
	}

	salt, err := hex.DecodeString(parts[0])
	if err != nil {
		return false
	}

	expectedHash, err := hex.DecodeString(parts[1])
	if err != nil {
		return false
	}

	actualHash := passwordHash(password, salt)
	return hmac.Equal(actualHash, expectedHash)
}

func passwordHash(password string, salt []byte) []byte {
	sum := sha256.Sum256(append(salt, []byte(password)...))
	return sum[:]
}

func generateJWT(user domain.User, secret string, expiresAt time.Time) (string, error) {
	header := jwtHeader{
		Algorithm: "HS256",
		Type:      "JWT",
	}
	claims := jwtClaims{
		Subject:   strconv.FormatInt(user.ID, 10),
		Username:  user.Username,
		ExpiresAt: expiresAt.Unix(),
		IssuedAt:  time.Now().Unix(),
	}

	encodedHeader, err := encodeJSONPart(header)
	if err != nil {
		return "", err
	}

	encodedClaims, err := encodeJSONPart(claims)
	if err != nil {
		return "", err
	}

	unsignedToken := encodedHeader + "." + encodedClaims
	signature := signJWT(unsignedToken, secret)

	return fmt.Sprintf("%s.%s", unsignedToken, signature), nil
}

func encodeJSONPart(value any) (string, error) {
	data, err := json.Marshal(value)
	if err != nil {
		return "", err
	}

	return base64.RawURLEncoding.EncodeToString(data), nil
}

func signJWT(unsignedToken string, secret string) string {
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(unsignedToken))
	return base64.RawURLEncoding.EncodeToString(mac.Sum(nil))
}

func (u *TestUseCase) userIDFromToken(token string) (int64, error) {
	token = strings.TrimSpace(token)
	if token == "" {
		return 0, ErrUnauthorized
	}

	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return 0, ErrUnauthorized
	}

	unsignedToken := parts[0] + "." + parts[1]
	expectedSignature := signJWT(unsignedToken, u.jwtSecret)
	if !hmac.Equal([]byte(expectedSignature), []byte(parts[2])) {
		return 0, ErrUnauthorized
	}

	payload, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return 0, ErrUnauthorized
	}

	var claims jwtClaims
	if err := json.Unmarshal(payload, &claims); err != nil {
		return 0, ErrUnauthorized
	}

	if claims.ExpiresAt < time.Now().Unix() {
		return 0, ErrUnauthorized
	}

	userID, err := strconv.ParseInt(claims.Subject, 10, 64)
	if err != nil || userID <= 0 {
		return 0, ErrUnauthorized
	}

	return userID, nil
}
