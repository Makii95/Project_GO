package usecase

import (
	"context"

	"payment-platform-server/internal/domain"
)

type Repository interface {
	GetHelloMessage(ctx context.Context) (string, error)
	SaveMessage(ctx context.Context, message string) (string, error)
	CreateUser(ctx context.Context, username string, passwordHash string) (domain.User, error)
	GetUserByUsername(ctx context.Context, username string) (domain.User, error)
	CreateOrder(ctx context.Context, userID int64, description string, status string) (domain.Order, error)
	GetOrdersByUserID(ctx context.Context, userID int64) ([]domain.Order, error)
}

type TestUseCase struct {
	repository Repository
	jwtSecret  string
}

func NewTestUseCase(repository Repository, jwtSecret string) *TestUseCase {
	return &TestUseCase{
		repository: repository,
		jwtSecret:  jwtSecret,
	}
}

func (u *TestUseCase) GetTestMessage(ctx context.Context) (string, error) {
	return u.repository.GetHelloMessage(ctx)
}

func (u *TestUseCase) SaveDBTestMessage(ctx context.Context, message string) (string, error) {
	return u.repository.SaveMessage(ctx, message)
}
