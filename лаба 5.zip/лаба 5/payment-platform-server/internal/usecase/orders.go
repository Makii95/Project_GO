package usecase

import (
	"context"
	"strings"

	"payment-platform-server/internal/domain"
)

const defaultOrderStatus = "created"

func (u *TestUseCase) CreateOrder(ctx context.Context, userID int64, description string) (domain.Order, error) {
	description = strings.TrimSpace(description)
	if description == "" {
		return domain.Order{}, ErrInvalidOrder
	}

	return u.repository.CreateOrder(ctx, userID, description, defaultOrderStatus)
}

func (u *TestUseCase) GetUserOrders(ctx context.Context, userID int64) ([]domain.Order, error) {
	return u.repository.GetOrdersByUserID(ctx, userID)
}
