package httpdelivery

import (
	"context"
	"errors"
	"net/http"

	"payment-platform-server/internal/usecase"
)

type userIDContextKey struct{}

func (h *TestHandler) AuthMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		token, ok := bearerToken(r)
		if !ok {
			http.Error(w, "authorization token is required", http.StatusUnauthorized)
			return
		}

		userID, err := h.useCase.UserIDFromToken(token)
		if err != nil {
			if errors.Is(err, usecase.ErrUnauthorized) {
				http.Error(w, "invalid authorization token", http.StatusUnauthorized)
				return
			}

			http.Error(w, "internal server error", http.StatusInternalServerError)
			return
		}

		ctx := context.WithValue(r.Context(), userIDContextKey{}, userID)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func userIDFromContext(ctx context.Context) (int64, bool) {
	userID, ok := ctx.Value(userIDContextKey{}).(int64)
	return userID, ok && userID > 0
}
