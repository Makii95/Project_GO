package domain

import "time"

type Order struct {
	ID          int64
	UserID      int64
	Description string
	Status      string
	CreatedAt   time.Time
}
