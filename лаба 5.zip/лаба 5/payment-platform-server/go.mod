module payment-platform-server

go 1.26

require github.com/lib/pq v1.10.9
